// Arquivos SASS
import './scss/index.scss'

// Dependencias
import 'jquery'
import 'bootstrap'

// Meus arquvos JS
import './js/core/includes'
import './js/plugins/cityButtons'