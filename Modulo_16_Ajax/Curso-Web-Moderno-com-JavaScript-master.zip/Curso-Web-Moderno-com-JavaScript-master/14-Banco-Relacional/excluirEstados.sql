DELETE FROM estados
WHERE sigla = 'MN'

DELETE FROM estados
WHERE id >= 1000

SELECT * FROM estados