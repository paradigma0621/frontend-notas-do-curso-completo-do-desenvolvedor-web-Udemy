this.ola = 'Olá, pessoal'
exports.bemVindo = 'Bem vindo ao node!'
module.exports.ateLogo = 'Até o próximo exemplo'
