import Pessoa from './pessoa'
// import './modulos/moduloA'
import './assets'

const atendente = new Pessoa
console.log(atendente.cumprimentar())