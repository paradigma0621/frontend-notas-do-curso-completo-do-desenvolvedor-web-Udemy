module.exports = {
    saudacao() {return 'Olá, eu sou o módulo B!!!'}
}