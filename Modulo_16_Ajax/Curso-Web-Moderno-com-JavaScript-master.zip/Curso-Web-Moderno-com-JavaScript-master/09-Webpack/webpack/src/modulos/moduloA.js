const moduloB = require('./moduloB')
console.log(moduloB.saudacao())