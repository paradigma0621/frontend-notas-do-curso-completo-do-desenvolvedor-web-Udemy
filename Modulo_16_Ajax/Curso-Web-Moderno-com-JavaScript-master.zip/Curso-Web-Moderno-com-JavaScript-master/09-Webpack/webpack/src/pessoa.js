import './modulos/moduloA'

export default class Pessoa {
    cumprimentar() {
        return 'Bom dia!'
    }
}